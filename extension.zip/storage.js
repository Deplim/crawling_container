var ui_html4=`<div id="storage_list">
			<table></table>
		</div>`

var storage = document.createElement('div');
storage.id = "storage";
document.body.appendChild(storage);

storage.innerHTML=ui_html4

